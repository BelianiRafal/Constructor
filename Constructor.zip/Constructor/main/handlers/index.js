import { handleProduct } from "./handleProduct.js";
import { handleLinks } from "./handleLinks.js";


export {
    handleLinks,
    handleProduct
}