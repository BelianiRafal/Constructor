export class Image {
  value = "";
  constructor({ value }) {
    this.value = value;
  }
}
