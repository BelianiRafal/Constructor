export class Language {
  constructor({ slug, title, name }) {
    this.slug = slug;
    this.title = title;
    this.name = name;
  }
}
