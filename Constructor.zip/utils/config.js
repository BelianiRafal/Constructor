export const config = {
  REDIRECT_URL: "http://localhost:5500",
  SCOPE: "https://www.googleapis.com/auth/drive",
  CLIENT_ID:
    "293627516788-cnogm6ddff7584galk3baas3hvqllqlp.apps.googleusercontent.com",
};
